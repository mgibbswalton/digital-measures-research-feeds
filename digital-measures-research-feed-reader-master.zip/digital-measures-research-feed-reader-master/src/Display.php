<?php

namespace wcob\FeedReader;

class Display
{
    public function getOuSnippet($label, $filename)
    {
        return "<div><h2>$label</h2><pre>{$this->getInclude($filename)}</pre></div>";
    }

    public function getHeader($title)
    {
        return "<h1>$title version @git-version@</h1>";
    }

    protected function getInclude($filename)
    {
        $realpath = realpath($filename);

        if (!$realpath) {
            throw new InvalidFile("File does not exist: $filename");
        }

        return "&lt;?php include '$realpath'; ?&gt;";
    }
}

class InvalidFile extends \InvalidArgumentException {}
