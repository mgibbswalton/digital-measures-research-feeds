# Digital Measures Research Feed Reader

This is a consumer script for the [microservice][microservice].

It fetches a list of departments, and writes the feeds to disk.
Then it displays php include code for those feeds.
This code can be added to an OmniUpdate asset for use on any page.

## Installation

Use [composer][composer] to install the dependencies.

    composer install --no-dev

Set your environment variables by creating the `.env` file from [example][env].

    cp .env.example .env

Use [box][box] to build the php archive.

    box build

Deploy the phar to your webserver.
Ensure that the webserver's php handler is set to process phar files.
There is an `.htaccess` file [example][htaccess] for Apache.

[microservice]:https://github.com/razorbacks/digital-measures-research-feeds
[composer]:https://getcomposer.org/
[env]:./.env.example
[box]:https://github.com/box-project/box2
[htaccess]:./public/.htaccess
