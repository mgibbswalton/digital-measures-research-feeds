<?php

$endpoint = 'https://digital-measures-research-feeds.walton.uark.edu/api/v1/departments';
$feedsDir = '';

$departments = array(
    'acct' => 'Accounting',
    'econ' => 'Economics',
    'isys' => 'Information Systems',
    'finn' => 'Finance',
    'mgmt' => 'Management',
    'mktg' => 'Marketing',
    'scmt' => 'Supply Chain Management',
);

require_once __DIR__.'/../vendor/autoload.php';

use jpuck\Error\Handler;
Handler::convertErrorsToExceptions();
Handler::swift();

if (empty($feedsDir)) {
    $feedsDir = dirname(Phar::running(false));
}

if (empty($feedsDir)) {
    $feedsDir = __DIR__;
}

$client = new wcob\FeedReader\Client;
$display = new wcob\FeedReader\Display;

echo $display->getHeader(getenv('APP_NAME'));

foreach ($departments as $code => $department) {
    $source = "$endpoint/$code";
    $destination = "$feedsDir/$code.html";

    if ($client->getFeed($source, $destination)) {
        echo $display->getOuSnippet($department, $destination);
    }
}
