<?php

namespace wcob\FeedReader;

class Client
{
    public function getFeed($source, $destination)
    {
        $html = file_get_contents($source);

        if (!$html) {
            return false;
        }

        if (empty($http_response_header)) {
            return false;
        }

        $headers = $this->parseHeaders($http_response_header);

        if ($headers['response_code'] != 200) {
            return false;
        }

        file_put_contents($destination, $html);

        return true;
    }

    /**
     * @link https://secure.php.net/manual/en/reserved.variables.httpresponseheader.php#117203
     */
    protected function parseHeaders($head)
    {
        $headers['response_code'] = null;

        foreach ($head as $header) {
            $keyValues = explode(':', $header, 2);

            if (isset($keyValues[1])) {
                $headers[trim($keyValues[0])] = trim($keyValues[1]);
                continue;
            }

            $headers []= $header;

            if (preg_match('#HTTP/[0-9\.]+\s+([0-9]+)#', $header, $out)) {
                $headers['response_code'] = intval($out[1]);
            }
        }

        return $headers;
    }
}
